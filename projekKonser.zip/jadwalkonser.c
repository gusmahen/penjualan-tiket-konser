void JadwalKonser(){
	int hari;
	int tutup = 1;
	while(tutup==1){
		system("cls");
	    printf("\n\n\t===================[ JADWAL MINGGU INI ]=====================\n\n");
	    printf("\t\t1. Jumat      [Lollapalooza]\n");
	    printf("\t\t2. Sabtu      [Coachella]\n");
	    printf("\t\t3. Minggu     [Soundrenaline]\n");
	    printf("\t______________________________________________________________\n");
	    printf("\tMasukkan nomor hari : ");
	    scanf("%d" ,&hari);
	    printf("\n\t=================[ KONSER YANG TERSEDIA ]===================\n\n");
		switch(hari){
			case 1:{
				printf("\n\n\t\t==============[ LOLLAPALOOZA ]==============\n\n");
			    printf("\t\t1. Taylor Swift      [10.00-12.00]\n");
			    printf("\t\t2. Metallica         [13.00-15.00]\n");
			    printf("\t\t3. Imagine Dragon    [17.00-19.00]\n");
			    printf("\t\t4. Arcade Fire       [20.00-22.00]\n");
			    printf("\t\t______________________________________________\n");
				break;
			}
			case 2:{
				printf("\n\n\t\t==============[ COACHELLA ]==============\n\n");
			    printf("\t\t1. Coldplay          [10.00-12.00]\n");
			    printf("\t\t2. Guns N' Roses'    [13.00-15.00]\n");
			    printf("\t\t3. Radiohead         [17.00-19.00]\n");
			    printf("\t\t4. Tame Impala       [20.00-22.00]\n");
			    printf("\t\t______________________________________________\n");
				break;
			}
			case 3:{
				printf("\n\n\t\t==============[ SOUNDRENALINE ]==============\n\n");
			    printf("\t\t1. NOAH              [10.00-12.00]\n");
			    printf("\t\t2. Nidji             [13.00-15.00]\n");
			    printf("\t\t3. isyana sarasvati  [17.00-19.00]\n");
			    printf("\t\t4. Fourtwnty         [20.00-22.00]\n");
			    printf("\t\t______________________________________________\n");
				break;
			}
		}
	    printf("\n\tUntuk Menutup Halaman Enter '0' Untuk Melihat Lagi Tekan '1':");
		scanf("%d", &tutup);
		system("cls");
	}
}
