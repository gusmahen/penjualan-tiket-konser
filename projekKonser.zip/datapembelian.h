typedef struct{
	char nama_pembeli[30];
	int jumlah_tiket;
	int kelas_tiket;
	int harga_tiket;
	int total_harga;
	int total_bayar;
	int kembalian;
	int no_hari;
    int no_konser;
    char nama_hari[255];
    char nama_konser[255];
}DataPembelian;

